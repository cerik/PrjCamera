#ifndef __IO_H
#define __IO_H
#include "sys.h"

#define ACOK GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_9)//��ȡֵ

void ACOK_Init(void);

#endif
