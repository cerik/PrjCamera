#ifndef __SMBUS_H
#define	__SMBUS_H

#include "stm32f10x.h"

void SMBUS_Init(void);

void SMBUS_ByteWrite(u8* pBuffer, u8 WriteAddr, u8 NumByteToRead);

void SMBUS_BufferRead(u8* pBuffer, u8 ReadAddr, u8 NumByteToRead);

#endif
