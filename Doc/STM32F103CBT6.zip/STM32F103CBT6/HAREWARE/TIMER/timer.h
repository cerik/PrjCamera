#ifndef __TIMER_H
#define __TIMER_H
#include "sys.h"

#define TIM3_CH1_Config(arr,psc) TIM3_Config(arr,psc,TIM_Channel_1,GPIO_Pin_4,TIM_IT_CC1)
#define TIM3_CH2_Config(arr,psc) TIM3_Config(arr,psc,TIM_Channel_2,GPIO_Pin_5,TIM_IT_CC2)

void TIM1_PWM_Init(u16 arr,u16 psc);

void TIM_Cap_Init(u16 arr,u16 psc);

void TIM2_Config(u16 arr,u16 psc);

void TIM3_Config(u16 arr,u16 psc,u8 ch,u16 pin,u16 cc);

#endif
