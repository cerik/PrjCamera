#ifndef __I2C_H
#define __I2C_H
#include "sys.h"
#include "delay.h"

typedef unsigned int UINT32;
typedef int          INT32;

#define MAXUINT16 0xFFFF

/* Private define ------------------------------------------------------------*/
#define AT24C01A		/* 24C01A,I2Cʱ��������24C02һ�� */

#define ADDR_24LC02		0xCE
#define I2C_PAGESIZE	4		/* 24C01/01Aҳ������4�� */

/* Private function prototypes -----------------------------------------------*/
void I2C_Configuration(void);
uint8_t I2C_Read(I2C_TypeDef *I2Cx,uint8_t I2C_Addr,uint8_t addr,uint8_t *buf,uint16_t num);
uint8_t I2C_Write(I2C_TypeDef *I2Cx,uint8_t I2C_Addr,uint8_t addr,uint8_t *buf,uint16_t num);


typedef struct{
    INT32  ms;
    UINT32 t0,t1;
}tagCounter;

#endif
