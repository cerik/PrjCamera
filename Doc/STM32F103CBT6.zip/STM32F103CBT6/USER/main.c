#include "sys.h"
#include "usart.h"
#include "delay.h"
#include "adc.h"
#include "led.h"
#include "timer.h"
#include "io.h"
#include "smbus.h"
#include "i2c.h"


//ADC demo
/*
extern __IO uint16_t ADC_ConvertedValue[10];

int main(void)
{
    u8 i;
    float voltage = 0;
    
    u8 t;
	u8 len;
    u16 res;
    
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);// �����ж����ȼ�����2
    
    uart_init(115200);
    delay_init();
    ADC1_Init();
    LED_Init();
    
   	while(1)
	{
        if(USART_RX_STA&0x8000)
		{					   
			len = USART_RX_STA&0x3fff;//�õ��˴ν��յ������ݳ���
			for(t=0; t<len; t++)
			{
				//USART1->DR=USART_RX_BUF[t];
				//while((USART1->SR&0X40)==0);//�ȴ����ͽ���
                res = USART_RX_BUF[t];
			}
            USART_RX_STA=0;
            switch(res) {
                case 100:
                    printf("adc|");
                    for (i=0; i<10; i++) {
                        voltage = (float) ADC_ConvertedValue[i] * 3.3 / 4095;
                        printf("%f,", voltage);
                    }
                    printf("\r\n");
                    break;
                case 101:
                    
                    break;
                default:
                    printf("break\r\n");
                    break;
            }
		}
        
        delay_ms(100);
	}
}
*/

/**
// timer demo

extern u8  TIM2CH2_CAPTURE_STA, TIM3CH1_CAPTURE_STA, TIM3CH2_CAPTURE_STA;	//���벶��״̬		    				
extern u16 TIM2CH2_CAPTURE_VAL, TIM3CH1_CAPTURE_VAL, TIM3CH2_CAPTURE_VAL;	//���벶��ֵ

int main(void)
{
    u32 temp=0; 
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);// �����ж����ȼ�����2
	delay_init();	    	 //��ʱ������ʼ��	
	uart_init(115200);	 			//9600	 
	LED_Init();		  	//��ʼ����LED���ӵ�Ӳ���ӿ�
 	TIM1_PWM_Init(899,0); 			//����Ƶ��PWMƵ��=72000/(899+1)=80Khz
 	TIM_Cap_Init(0XFFFF,72-1);		//��1Mhz��Ƶ�ʼ��� 
   	while(1)
	{
 		delay_ms(10);
		TIM_SetCompare1(TIM1,TIM_GetCapture1(TIM1)+1);
		if(TIM_GetCapture1(TIM1)==300)TIM_SetCompare1(TIM1,0);		 
		if(TIM2CH2_CAPTURE_STA&0X80)//�ɹ�������һ�θߵ�ƽ
		{
			temp=TIM2CH2_CAPTURE_STA&0X3F;
			temp*=65536;					//���ʱ���ܺ�
			temp+=TIM2CH2_CAPTURE_VAL;		//�õ��ܵĸߵ�ƽʱ��
			printf("TIM2CH2_HIGH:%d us\r\n",temp);	//��ӡ�ܵĸߵ�ƽʱ��
 			TIM2CH2_CAPTURE_STA=0;			//������һ�β���
 		}
        if(TIM3CH1_CAPTURE_STA&0X80)//�ɹ�������һ�θߵ�ƽ
		{
			temp=TIM3CH1_CAPTURE_STA&0X3F;
			temp*=65536;					//���ʱ���ܺ�
			temp+=TIM3CH1_CAPTURE_VAL;		//�õ��ܵĸߵ�ƽʱ��
			printf("TIM3CH1_HIGH:%d us\r\n",temp);	//��ӡ�ܵĸߵ�ƽʱ��
 			TIM3CH1_CAPTURE_STA=0;			//������һ�β���
 		}
        if(TIM3CH2_CAPTURE_STA&0X80)//�ɹ�������һ�θߵ�ƽ
		{
			temp=TIM3CH2_CAPTURE_STA&0X3F;
			temp*=65536;					//���ʱ���ܺ�
			temp+=TIM3CH2_CAPTURE_VAL;		//�õ��ܵĸߵ�ƽʱ��
			printf("TIM3CH2_HIGH:%d us\r\n",temp);	//��ӡ�ܵĸߵ�ƽʱ��
 			TIM3CH2_CAPTURE_STA=0;			//������һ�β���
 		}
	}
}
*/

/*
//ACOK IO
int main(void)
{
    uart_init(115200);
    delay_init();
    ACOK_Init();
    
   	while(1)
	{
        printf("%d\r\n", ACOK);
        delay_ms(100);
	}
}
*/

/*
//SMBUS
int main(void)
{
    u16 buf;
	//RCC_Configuration();
	delay_init();
    LED_Init();
	uart_init(115200);
	SMBUS_Init();

	SMBUS_BufferRead((u8*)&buf, 0xff, 2);
	printf("DeviceID: %04x\r\n", buf);
	
	SMBUS_BufferRead((u8*)&buf, 0xfe, 2);
	printf("ManufacturerID: %04x\r\n", buf);

	SMBUS_BufferRead((u8*)&buf, 0x3f, 2);
	printf("InputCurrent: %04x\r\n", buf);

	SMBUS_BufferRead((u8*)&buf, 0x15, 2);
	printf("ChargeVoltage: %04x\r\n", buf);
	
	buf = 0x13f0;

	SMBUS_ByteWrite((u8*)&buf, 0x15, 2);
	
	buf = 0;
	SMBUS_BufferRead((u8*)&buf, 0x15, 2);
	printf("ChargeVoltage: %04x\r\n", buf);

	SMBUS_BufferRead((u8*)&buf, 0x14, 2);
	printf("ChargeCurrent: %04x\r\n", buf);
	
	buf = 0x13c0;

	SMBUS_ByteWrite((u8*)&buf, 0x14, 2);
	
	buf = 0;
	SMBUS_BufferRead((u8*)&buf, 0x14, 2);
	printf("ChargeCurrent: %04x\r\n", buf);

	SMBUS_BufferRead((u8*)&buf, 0x12, 2);
	printf("ChargeOption: %04x\r\n\r\n", buf);
	
	while(1){
        LED1 = !LED1;
        LED0 = !LED0;
        delay_ms(10);
    }
}
*/


int main(void)
{
	uint8_t ReadBuffer[256];
    
    uart_init(115200);
    delay_init();
    LED_Init();
    I2C_Configuration();
    
    I2C_Read(I2C2, ADDR_24LC02, 0x12, ReadBuffer, 1);
    printf("0x12 : %d \r\n",ReadBuffer[0]);
    
    I2C_Read(I2C2,ADDR_24LC02,0x10,ReadBuffer,1);
    printf("0x10 : %d \r\n",ReadBuffer[0]);
   
    ReadBuffer[0] = 0x5;
    I2C_Write(I2C2, ADDR_24LC02, 0x10, ReadBuffer, 1);
    printf("0x10 : %d \r\n", ReadBuffer[0]);
    
    while(1) {
        LED1 = !LED1;
        delay_ms(10);
    }
}

